package AlgoDS.Project2;

import java.util.*;

public class DFS {
    enum Color { WHITE, GRAY, BLACK }

    public static void run(Graph g) {
        Map<String, Color> color = new HashMap<>();
        for (String v : g.vertices) color.put(v, Color.WHITE);
        List<String> topoOrder = new ArrayList<>();
        List<List<String>> cycles = new ArrayList<>();
        Stack<String> stack = new Stack<>();

        for (String v : g.vertices) {
            if (color.get(v) == Color.WHITE)
                dfsVisit(g, v, color, stack, cycles, topoOrder);
        }

        if (cycles.isEmpty()) {
            Collections.reverse(topoOrder);
            System.out.println("\n--- Topological Sort (Acyclic Graph) ---");
            System.out.println(String.join(" -> ", topoOrder));
        } else {
            System.out.println("\n--- Cycles Found ---");
            for (List<String> c : cycles)
                System.out.println(String.join(" -> ", c));
        }
    }

    private static void dfsVisit(Graph g, String u, Map<String, Color> color, Stack<String> stack,
                                 List<List<String>> cycles, List<String> topoOrder) {
        color.put(u, Color.GRAY);
        stack.push(u);

        for (Edge e : g.adj.getOrDefault(u, new ArrayList<>())) {
            if (color.get(e.v) == Color.GRAY) {
                List<String> cycle = new ArrayList<>();
                for (String s : stack)
                    cycle.add(s);
                cycle.add(e.v);
                cycles.add(new ArrayList<>(cycle));
            } else if (color.get(e.v) == Color.WHITE) {
                dfsVisit(g, e.v, color, stack, cycles, topoOrder);
            }
        }

        stack.pop();
        color.put(u, Color.BLACK);
        topoOrder.add(u);
    }
}

