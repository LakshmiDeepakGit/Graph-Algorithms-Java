package AlgoDS.Project2;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter input file path (e.g., inputs/graph1.txt): ");
        String path = sc.nextLine();

        try {
            Graph g = Graph.fromFile(path);

            if (g.source != null) {
            	System.out.println("Going to run Dijkstra algorithm ...... with source = "+g.source);
                Dijkstra.run(g, g.source);
            }

            if (!g.directed) {
            	System.out.println("Going to run Kruskal algorithm ...... ");
                Kruskal.run(g);
            } else {
            	System.out.println("Going to run DFS algorithm ...... ");
                DFS.run(g);
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

