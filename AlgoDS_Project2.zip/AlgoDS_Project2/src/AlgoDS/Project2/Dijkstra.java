package AlgoDS.Project2;

import java.util.*;

public class Dijkstra {
    public static void run(Graph g, String source) {
        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> parent = new HashMap<>();

        for (String v : g.vertices) {
            dist.put(v, Integer.MAX_VALUE);
            parent.put(v, null);
        }

        dist.put(source, 0);
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a.cost));
        pq.add(new Node(source, 0));

        while (!pq.isEmpty()) {
            Node cur = pq.poll();

            for (Edge e : g.adj.getOrDefault(cur.name, new ArrayList<>())) {
                int newDist = cur.cost + e.w;
                if (newDist < dist.get(e.v)) {
                    dist.put(e.v, newDist);
                    parent.put(e.v, cur.name);
                    pq.add(new Node(e.v, newDist));
                }
            }
        }

        System.out.println("\n--- Shortest Paths from " + source + " ---");
        for (String v : g.vertices) {
            if (dist.get(v) == Integer.MAX_VALUE)
                System.out.println(source + " -> " + v + " : No path");
            else
                System.out.println(source + " -> " + v + " : " + reconstructPath(parent, v) + " | Cost = " + dist.get(v));
        }
    }

    private static String reconstructPath(Map<String, String> parent, String v) {
        List<String> path = new ArrayList<>();
        while (v != null) {
            path.add(v);
            v = parent.get(v);
        }
        Collections.reverse(path);
        return String.join(" -> ", path);
    }
}

class Node {
    String name;
    int cost;

    Node(String name, int cost) {
        this.name = name;
        this.cost = cost;
    }
}
