package AlgoDS.Project2;

import java.util.*;

public class Graph {
    public Map<String, List<Edge>> adj;
    public boolean directed;
    public Set<String> vertices;

    public Graph(boolean directed) {
        this.directed = directed;
        adj = new HashMap<>();
        vertices = new HashSet<>();
    }

    public void addEdge(String u, String v, int w) {
        adj.putIfAbsent(u, new ArrayList<>());
        adj.putIfAbsent(v, new ArrayList<>());
        adj.get(u).add(new Edge(u, v, w));
        vertices.add(u);
        vertices.add(v);

        if (!directed) {
            adj.get(v).add(new Edge(v, u, w));
        }
    }

    public static Graph fromFile(String path) throws Exception {
        Scanner sc = new Scanner(new java.io.File(path));
        int n = sc.nextInt();
        int m = sc.nextInt();
        String type = sc.next();
        boolean directed = type.equalsIgnoreCase("D");
        Graph g = new Graph(directed);

        for (int i = 0; i < m; i++) {
            String u = sc.next();
            String v = sc.next();
            int w = sc.nextInt();
            g.addEdge(u, v, w);
        }

        String source = null;
        if (sc.hasNext()) source = sc.next();
        g.source = source;

        sc.close();
        return g;
    }

    public String source = null;
}

class Edge {
    String u, v;
    int w;

    public Edge(String u, String v, int w) {
        this.u = u;
        this.v = v;
        this.w = w;
    }
}
