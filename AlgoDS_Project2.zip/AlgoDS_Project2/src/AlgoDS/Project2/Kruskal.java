package AlgoDS.Project2;

import java.util.*;

public class Kruskal {
    public static void run(Graph g) {
        List<Edge> edges = new ArrayList<>();
        for (List<Edge> list : g.adj.values()) {
            edges.addAll(list);
        }

        // For undirected, remove duplicates
        if (!g.directed) {
            Set<String> seen = new HashSet<>();
            edges.removeIf(e -> !seen.add(e.u + "-" + e.v) && !seen.add(e.v + "-" + e.u));
        }

        edges.sort(Comparator.comparingInt(e -> e.w));

        UnionFind uf = new UnionFind(g.vertices);
        int total = 0;
        List<Edge> mst = new ArrayList<>();

        for (Edge e : edges) {
            if (uf.union(e.u, e.v)) {
                mst.add(e);
                total += e.w;
            }
        }

        System.out.println("\n--- Minimum Spanning Tree (Kruskal) ---");
        for (Edge e : mst) {
            System.out.println(e.u + " - " + e.v + " : " + e.w);
        }
        System.out.println("Total Weight = " + total);
    }
}

class UnionFind {
    private Map<String, String> parent = new HashMap<>();

    public UnionFind(Set<String> vertices) {
        for (String v : vertices) parent.put(v, v);
    }

    public String find(String v) {
        if (parent.get(v).equals(v)) return v;
        parent.put(v, find(parent.get(v)));
        return parent.get(v);
    }

    public boolean union(String a, String b) {
        String pa = find(a), pb = find(b);
        if (pa.equals(pb)) return false;
        parent.put(pa, pb);
        return true;
    }
}
